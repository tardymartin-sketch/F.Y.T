// ===========================================
// F.Y.T - Athlete Components Index
// src/components/athlete/index.ts
// Export centralisé des composants athlète
// ===========================================

// Navigation
export { BottomNav } from './BottomNav';
export type { AthleteView } from './BottomNav';

export { FloatingActionButton } from './FloatingActionButton';
export type { SessionState } from './FloatingActionButton';

// Les composants suivants seront ajoutés dans les prochaines étapes:
// export { HomeAthlete } from './HomeAthlete';
// export { SessionSelector } from './SessionSelector';
// export { HistoryAthlete } from './HistoryAthlete';
// export { CoachMessages } from './CoachMessages';
// export { ProfileAthlete } from './ProfileAthlete';
