// ===========================================
// F.Y.T - Layouts Index
// src/layouts/index.ts
// Export centralisé des layouts
// ===========================================

export { AthleteLayout, AthleteLayoutMinimal } from './AthleteLayout';
export { CoachLayout } from './CoachLayout';
