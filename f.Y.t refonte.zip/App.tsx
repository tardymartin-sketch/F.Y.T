// ============================================================
// F.Y.T - APP PRINCIPAL (Version avec Session en cours persistante)
// App.tsx
// Gestion de la session active avec persistence localStorage
// ============================================================

import React, { useState, useEffect } from 'react';
import { Session } from '@supabase/supabase-js';
import { supabase } from './src/supabaseClient';
import {
  fetchTrainingPlans,
  fetchSessionLogs,
  saveSessionLog,
  deleteSessionLog,
  fetchTeamAthletes,
  fetchAllUsers,
  updateUserCoach,
  fetchCurrentUserProfile,
  updateUserProfile,
  fetchWeekOrganizerLogs,
  fetchActiveWeekOrganizer,
  saveWeekOrganizerLog,
  deleteWeekOrganizerLog,
  fetchTeamComments,
  saveAthleteComment,
  markCommentsAsRead,
  fetchAthleteGroups,
  createAthleteGroup,
  updateAthleteGroup,
  deleteAthleteGroup,
  updateGroupMembers,
  fetchAthleteGroupWithMembers,
  fetchAthleteGroupsForAthlete,
  fetchActiveWeekOrganizersForAthlete, // MODIFIÉ: nouvelle fonction pour obtenir tous les messages
} from './src/services/supabaseService';

import type { AthleteGroupWithCount } from './types';
import { 
  canAthleteViewMessage,
  filterVisibleMessages,
  canAccessCoachMode,
  canAccessAthleteMode,
} from './types';
import type { ActiveMode } from './types';
import { 
  WorkoutRow, 
  SessionLog, 
  User, 
  FilterState,
  ProfileRow,
  WeekOrganizerLog,
  AthleteComment
} from './types';

// Components
import { Auth } from './src/components/Auth';
import { LoadingScreen } from './src/components/LoadingScreen';
import { Sidebar } from './src/components/Sidebar';
import { Home } from './src/components/Home';
import { ActiveSession } from './src/components/ActiveSession';
import { History } from './src/components/History';
import { TeamView } from './src/components/TeamView';
import { AdminUsersView } from './src/components/AdminUsersView';
import { SettingsView } from './src/components/SettingsView';
import { StravaImport } from './src/components/StravaImport';
import { Menu } from 'lucide-react';

// NEW: Athlete Layout Components
import { AthleteLayout } from './src/layouts/AthleteLayout';
import type { AthleteView } from './src/components/athlete/BottomNav';
import type { SessionState } from './src/components/athlete/FloatingActionButton';

// NEW: Hooks
import { useIsMobile } from './src/hooks';

// Constante pour le stockage du mode actif
const ACTIVE_MODE_KEY = 'F.Y.T_active_mode';

const App: React.FC = () => {
  // Auth State
  const [session, setSession] = useState<Session | null>(null);
  const [authLoading, setAuthLoading] = useState(true);

  // User State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  
  // Mode actif (athlete, coach, admin) - lu depuis localStorage
  const [activeMode, setActiveMode] = useState<ActiveMode | null>(null);

  // Navigation
  const [currentView, setCurrentView] = useState<string>('home');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Data States
  const [trainingData, setTrainingData] = useState<WorkoutRow[]>([]);
  const [history, setHistory] = useState<SessionLog[]>([]);
  const [filters, setFilters] = useState<FilterState>({
    selectedAnnee: null,
    selectedMois: null,
    selectedSemaine: null,
    selectedSeances: [],
  });
  const [dataLoading, setDataLoading] = useState(false);
  
  // Active Session State - MODIFIÉ: Persistence via localStorage
  const [activeSessionData, setActiveSessionData] = useState<WorkoutRow[] | null>(null);
  const [editingSession, setEditingSession] = useState<SessionLog | null>(null);
  const [hasActiveSession, setHasActiveSession] = useState(false);

  // Week Organizer State - MODIFIÉ: tableau au lieu d'un seul
  const [activeWeekOrganizers, setActiveWeekOrganizers] = useState<WeekOrganizerLog[]>([]);
  const [pastWeekOrganizers, setPastWeekOrganizers] = useState<WeekOrganizerLog[]>([]);

  // ===========================================
  // AUTH EFFECTS
  // ===========================================
  
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setAuthLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  // ===========================================
  // PERSISTENCE DE LA SESSION EN COURS
  // ===========================================

  // Vérifier au chargement s'il y a une session en cours
  useEffect(() => {
    const savedSession = localStorage.getItem('F.Y.T_active_session');
    if (savedSession) {
      try {
        const parsed = JSON.parse(savedSession);
        if (parsed.sessionData && parsed.logs) {
          setHasActiveSession(true);
        }
      } catch (e) {
        console.error('Erreur parsing session sauvegardée:', e);
        localStorage.removeItem('F.Y.T_active_session');
      }
    }
  }, []);

  // Observer les changements dans localStorage
  useEffect(() => {
    const handleStorageChange = () => {
      const savedSession = localStorage.getItem('F.Y.T_active_session');
      setHasActiveSession(!!savedSession);
    };

    // Vérifier périodiquement (pour les changements dans le même onglet)
    const interval = setInterval(handleStorageChange, 1000);

    window.addEventListener('storage', handleStorageChange);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(interval);
    };
  }, []);

  // ===========================================
  // LOAD USER AND DATA
  // ===========================================

  useEffect(() => {
    if (session) {
      loadUserProfile();
    } else {
      setCurrentUser(null);
      setTrainingData([]);
      setHistory([]);
    }
  }, [session]);

  useEffect(() => {
    if (currentUser) {
      loadUserData();
      
      // Charger le mode actif depuis localStorage
      const storedMode = localStorage.getItem(ACTIVE_MODE_KEY) as ActiveMode | null;
      if (storedMode && ['athlete', 'coach', 'admin'].includes(storedMode)) {
        // Vérifier que l'utilisateur a bien accès à ce mode
        if (storedMode === 'athlete' && canAccessAthleteMode(currentUser)) {
          setActiveMode('athlete');
        } else if ((storedMode === 'coach' || storedMode === 'admin') && canAccessCoachMode(currentUser)) {
          setActiveMode(storedMode);
        } else {
          // Mode invalide, utiliser le rôle principal
          setActiveMode(currentUser.role);
          localStorage.setItem(ACTIVE_MODE_KEY, currentUser.role);
        }
      } else {
        // Pas de mode stocké, utiliser le rôle principal
        setActiveMode(currentUser.role);
        localStorage.setItem(ACTIVE_MODE_KEY, currentUser.role);
      }
    }
  }, [currentUser]);

  const loadUserProfile = async () => {
    if (!session?.user?.id) return;
    
    try {
      const profile = await fetchCurrentUserProfile(session.user.id);
      setCurrentUser(profile);
    } catch (error) {
      console.error("Erreur chargement profil:", error);
    }
  };

  const loadUserData = async () => {
    if (!currentUser) return;
    
    setDataLoading(true);
    try {
      const [plans, logs] = await Promise.all([
        fetchTrainingPlans(currentUser.id),
        fetchSessionLogs(currentUser.id)
      ]);
      
      setTrainingData(plans);
      setHistory(logs);
    } catch (error) {
      console.error("Erreur chargement données:", error);
    } finally {
      setDataLoading(false);
    }
  };

  // ===========================================
  // ATHLETE GROUPS HANDLERS
  // ===========================================

  const handleFetchAthleteGroups = async (coachId: string) => {
    return await fetchAthleteGroups(coachId);
  };

  const handleCreateAthleteGroup = async (name: string, description: string, color: string) => {
    if (!currentUser) return;
    await createAthleteGroup(currentUser.id, name, description, color);
  };

  const handleUpdateAthleteGroup = async (
    groupId: string, 
    name: string, 
    description: string, 
    color: string
  ) => {
    await updateAthleteGroup(groupId, name, description, color);
  };

  const handleDeleteAthleteGroup = async (groupId: string) => {
    await deleteAthleteGroup(groupId);
  };

  const handleUpdateGroupMembers = async (groupId: string, athleteIds: string[]) => {
    await updateGroupMembers(groupId, athleteIds);
  };

  const handleLoadGroupMembers = async (groupId: string) => {
    return await fetchAthleteGroupWithMembers(groupId);
  };

  // MODIFIÉ: Charger TOUS les week organizers pour les athlètes
  useEffect(() => {
    const loadWeekOrganizers = async () => {
      if (!currentUser || !currentUser.coachId) return;
      
      try {
        // Utiliser la nouvelle fonction qui retourne TOUS les messages visibles
        const activeMessages = await fetchActiveWeekOrganizersForAthlete(
          currentUser.coachId,
          currentUser.id
        );
        setActiveWeekOrganizers(activeMessages);
        
        // Charger les messages passés visibles
        const athleteGroupIds = await fetchAthleteGroupsForAthlete(currentUser.id);
        const all = await fetchWeekOrganizerLogs(currentUser.coachId);
        
        const activeIds = new Set(activeMessages.map(m => m.id));
        const visible = all.filter(log => {
          const endDate = new Date(log.endDate);
          const isVisible = canAthleteViewMessage(log, currentUser.id, athleteGroupIds);
          return endDate < new Date() && isVisible && !activeIds.has(log.id);
        });
        
        setPastWeekOrganizers(visible.slice(0, 5));
      } catch (error) {
        console.error("Erreur chargement week organizers:", error);
      }
    };

    loadWeekOrganizers();
  }, [currentUser]);

  // ===========================================
  // SESSION HANDLERS
  // ===========================================

  const handleStartSession = () => {
    const sessionData = trainingData.filter(d => 
      d.annee === filters.selectedAnnee && 
      d.moisNum === filters.selectedMois && 
      d.semaine === filters.selectedSemaine && 
      filters.selectedSeances.includes(d.seance)
    );
    
    if (sessionData.length > 0) {
      setActiveSessionData(sessionData);
      setEditingSession(null);
      setCurrentView('active');
      setHasActiveSession(true);
    }
  };

  // Reprendre une session en cours depuis localStorage
  const handleResumeSession = () => {
    const savedSession = localStorage.getItem('F.Y.T_active_session');
    if (savedSession) {
      try {
        const parsed = JSON.parse(savedSession);
        // Reconstruire les données de session
        if (parsed.sessionData) {
          const sessionData = trainingData.filter(d => {
            return parsed.sessionData.some((s: any) => 
              s.seance === d.seance && 
              s.annee === d.annee && 
              s.moisNum === d.moisNum && 
              s.semaine === d.semaine
            );
          });
          if (sessionData.length > 0) {
            setActiveSessionData(sessionData);
            setCurrentView('active');
          }
        }
      } catch (e) {
        console.error('Erreur reprise session:', e);
      }
    }
  };

  const handleSaveSession = async (log: SessionLog) => {
    if (!currentUser) return;
    
    try {
      await saveSessionLog(log, currentUser.id);
      await loadUserData();
      setActiveSessionData(null);
      setEditingSession(null);
      setHasActiveSession(false);
      localStorage.removeItem('F.Y.T_active_session');
      setCurrentView('home');
    } catch (error) {
      console.error("Erreur sauvegarde session:", error);
      throw error;
    }
  };

  const handleCancelSession = () => {
    setActiveSessionData(null);
    setEditingSession(null);
    setHasActiveSession(false);
    localStorage.removeItem('F.Y.T_active_session');
    setCurrentView('home');
  };

  const handleDeleteSession = async (sessionId: string) => {
    try {
      await deleteSessionLog(sessionId);
      setHistory(prev => prev.filter(s => s.id !== sessionId));
    } catch (error) {
      console.error("Erreur suppression session:", error);
    }
  };

  const handleEditSession = (log: SessionLog) => {
    const sessionData = trainingData.filter(d =>
      d.annee === log.sessionKey.annee &&
      d.semaine === log.sessionKey.semaine &&
      log.sessionKey.seance.includes(d.seance)
    );

    if (sessionData.length > 0) {
      setActiveSessionData(sessionData);
      setEditingSession(log);
      setCurrentView('active');
    } else {
      const minimalData: WorkoutRow[] = log.exercises.map((ex, idx) => ({
        id: idx,
        annee: log.sessionKey.annee,
        moisNom: '',
        moisNum: log.sessionKey.moisNum,
        semaine: log.sessionKey.semaine,
        seance: log.sessionKey.seance,
        ordre: idx + 1,
        exercice: ex.exerciseName,
        series: ex.sets.length.toString(),
        repsDuree: '',
        repos: '',
        tempoRpe: '',
        notes: '',
        video: ''
      }));
      setActiveSessionData(minimalData);
      setEditingSession(log);
      setCurrentView('active');
    }
  };

  const handleFetchTeam = async (coachId: string) => {
    return await fetchTeamAthletes(coachId);
  };

  const handleFetchAthleteHistory = async (athleteId: string) => {
    return await fetchSessionLogs(athleteId);
  };

  const handleFetchAllUsers = async () => {
    return await fetchAllUsers();
  };

  const handleUpdateCoach = async (userId: string, coachId: string | null) => {
    await updateUserCoach(userId, coachId);
  };

  const handleUpdateProfile = async (updates: Partial<User>) => {
    if (!currentUser) return;
    
    const dbUpdates: Partial<ProfileRow> = {};
    if (updates.firstName) dbUpdates.first_name = updates.firstName;
    if (updates.lastName) dbUpdates.last_name = updates.lastName;
    
    await updateUserProfile(currentUser.id, dbUpdates);
    setCurrentUser({ ...currentUser, ...updates });
  };

  // ===========================================
  // WEEK ORGANIZER HANDLERS
  // ===========================================

  const handleFetchWeekOrganizerLogs = async (coachId: string) => {
    return await fetchWeekOrganizerLogs(coachId);
  };

  const handleSaveWeekOrganizerLog = async (log: WeekOrganizerLog) => {
    return await saveWeekOrganizerLog(log);
  };

  const handleDeleteWeekOrganizerLog = async (logId: string) => {
    await deleteWeekOrganizerLog(logId);
  };

  // ===========================================
  // ATHLETE COMMENTS HANDLERS
  // ===========================================

  const handleFetchTeamComments = async (coachId: string, onlyUnread?: boolean) => {
    return await fetchTeamComments(coachId, onlyUnread);
  };

  const handleMarkCommentsAsRead = async (commentIds: string[]) => {
    await markCommentsAsRead(commentIds);
  };

  const handleSaveAthleteComment = async (exerciseName: string, comment: string, sessionId: string) => {
    if (!currentUser) return;
    await saveAthleteComment({
      oderId: currentUser.id,
      sessionId,
      exerciseName,
      comment,
      isRead: false,
    });
  };

  // ===========================================
  // LOGOUT HANDLER
  // ===========================================

  const handleLogout = async () => {
    await supabase.auth.signOut();
    localStorage.removeItem('F.Y.T_active_session');
  };

  // ===========================================
  // NAVIGATION HANDLER - MODIFIÉ pour session en cours
  // ===========================================

  const handleViewChange = (view: string) => {
    // Si on clique sur "active" depuis le menu et qu'il y a une session en cours
    if (view === 'active' && hasActiveSession && !activeSessionData) {
      handleResumeSession();
    } else {
      setCurrentView(view);
    }
  };

  // ===========================================
  // RENDER HELPERS
  // ===========================================

  // Convertir la view actuelle en AthleteView pour le bottom nav
  const getAthleteView = (): AthleteView => {
    switch (currentView) {
      case 'home': return 'home';
      case 'history': return 'history';
      case 'coach': return 'coach';
      case 'settings': return 'profile';
      default: return 'home';
    }
  };

  // Convertir AthleteView en view interne
  const handleAthleteViewChange = (view: AthleteView) => {
    switch (view) {
      case 'home': setCurrentView('home'); break;
      case 'history': setCurrentView('history'); break;
      case 'coach': setCurrentView('coach'); break; // Vue messages du coach
      case 'profile': setCurrentView('settings'); break;
    }
  };

  // Déterminer l'état du FAB
  const getSessionState = (): SessionState => {
    if (hasActiveSession) return 'active';
    return 'none';
  };

  // Handler pour le FAB
  const handleFabClick = () => {
    if (hasActiveSession) {
      handleResumeSession();
    } else {
      // Ouvrir le sélecteur de séance ou démarrer directement
      setCurrentView('home');
    }
  };

  // ===========================================
  // RENDER
  // ===========================================

  if (authLoading) {
    return <LoadingScreen />;
  }

  if (!session) {
    return <Auth onAuth={() => {}} />;
  }

  if (!currentUser || !activeMode) {
    return <LoadingScreen />;
  }

  // Vérifications basées sur le rôle principal (pour les permissions)
  const isAdmin = currentUser.role === 'admin';
  const isCoach = currentUser.role === 'coach';
  
  // Vérifications basées sur le mode actif (pour l'affichage)
  const showAthleteInterface = activeMode === 'athlete';
  const showCoachInterface = activeMode === 'coach' || activeMode === 'admin';
  
  // Peut-on switcher de mode ?
  const canSwitchToCoach = canAccessCoachMode(currentUser);
  const canSwitchToAthlete = canAccessAthleteMode(currentUser);

  // Handler pour changer de mode
  const handleSwitchMode = (newMode: ActiveMode) => {
    localStorage.setItem(ACTIVE_MODE_KEY, newMode);
    window.location.reload();
  };

  // ===========================================
  // RENDER ATHLETE (Mobile-First avec Bottom Nav)
  // ===========================================
  if (showAthleteInterface) {
    // Masquer la navigation pendant une session active
    const hideNavigation = currentView === 'active' && activeSessionData !== null;

    return (
      <AthleteLayout
        currentView={getAthleteView()}
        onViewChange={handleAthleteViewChange}
        unreadMessages={0} // TODO: implémenter le compteur de messages non lus
        sessionState={getSessionState()}
        onFabClick={handleFabClick}
        hideNavigation={hideNavigation}
      >
        <div className="p-4">
          {dataLoading ? (
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full" />
            </div>
          ) : (
            <>
              {currentView === 'home' && (
                <Home
                  data={trainingData}
                  filters={filters}
                  setFilters={setFilters}
                  onStartSession={handleStartSession}
                  user={currentUser}
                  history={history}
                  activeWeekOrganizers={activeWeekOrganizers}
                  pastWeekOrganizers={pastWeekOrganizers}
                />
              )}

              {currentView === 'active' && activeSessionData && (
                <ActiveSession
                  sessionData={activeSessionData}
                  history={history}
                  onSave={handleSaveSession}
                  onCancel={handleCancelSession}
                  initialLog={editingSession}
                  userId={currentUser.id}
                  onSaveComment={handleSaveAthleteComment}
                />
              )}

              {currentView === 'history' && (
                <History
                  history={history}
                  onDelete={handleDeleteSession}
                  onEdit={handleEditSession}
                  userId={currentUser.id}
                />
              )}

              {/* Vue Messages Coach (placeholder - sera remplacé par CoachMessages à l'étape 1.6) */}
              {currentView === 'coach' && (
                <div className="space-y-6">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-emerald-500 flex items-center justify-center">
                      <span className="text-white text-lg">💬</span>
                    </div>
                    <div>
                      <h1 className="text-xl font-bold text-white">Messages de ton coach</h1>
                      <p className="text-sm text-slate-400">Conseils et instructions</p>
                    </div>
                  </div>

                  {/* Messages actifs */}
                  {activeWeekOrganizers.length > 0 ? (
                    <div className="space-y-4">
                      <h2 className="text-sm font-medium text-slate-400 uppercase tracking-wide">
                        Messages actifs
                      </h2>
                      {activeWeekOrganizers.map((msg) => (
                        <div 
                          key={msg.id}
                          className="bg-slate-800/50 border border-slate-700 rounded-xl p-4 space-y-2"
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-blue-400 font-medium">
                              📅 {new Date(msg.startDate).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })} 
                              {' - '}
                              {new Date(msg.endDate).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}
                            </span>
                          </div>
                          {msg.title && (
                            <h3 className="font-semibold text-white">{msg.title}</h3>
                          )}
                          <div 
                            className="text-slate-300 text-sm rich-text-display"
                            dangerouslySetInnerHTML={{ __html: msg.message }}
                          />
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="bg-slate-800/30 border border-slate-700/50 rounded-xl p-8 text-center">
                      <div className="text-4xl mb-3">📭</div>
                      <p className="text-slate-400">Aucun message actif pour le moment</p>
                      <p className="text-slate-500 text-sm mt-1">Ton coach t'enverra des instructions ici</p>
                    </div>
                  )}

                  {/* Messages passés */}
                  {pastWeekOrganizers.length > 0 && (
                    <div className="space-y-4">
                      <h2 className="text-sm font-medium text-slate-400 uppercase tracking-wide">
                        Messages précédents
                      </h2>
                      {pastWeekOrganizers.map((msg) => (
                        <div 
                          key={msg.id}
                          className="bg-slate-800/30 border border-slate-700/50 rounded-xl p-4 opacity-70"
                        >
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-xs text-slate-500">
                              {new Date(msg.startDate).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })} 
                              {' - '}
                              {new Date(msg.endDate).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}
                            </span>
                          </div>
                          {msg.title && (
                            <h3 className="font-medium text-slate-300 text-sm">{msg.title}</h3>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {currentView === 'settings' && (
                <SettingsView
                  user={currentUser}
                  onUpdateProfile={handleUpdateProfile}
                  onLogout={handleLogout}
                  activeMode={activeMode}
                  canSwitchToCoach={canSwitchToCoach}
                  canSwitchToAthlete={canSwitchToAthlete}
                  onSwitchMode={handleSwitchMode}
                />
              )}

              {currentView === 'import' && (
                <StravaImport user={currentUser} />
              )}
            </>
          )}
        </div>
      </AthleteLayout>
    );
  }

  // ===========================================
  // RENDER COACH / ADMIN (Desktop-First avec Sidebar)
  // ===========================================
  return (
    <div className="min-h-screen bg-slate-950 flex">
      <Sidebar
        currentView={currentView}
        setCurrentView={handleViewChange}
        isAdmin={isAdmin}
        isCoach={isCoach}
        onLogout={handleLogout}
        user={currentUser}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        hasActiveSession={hasActiveSession}
      />
      
      <main className="flex-1 lg:ml-0 overflow-y-auto">
        {/* Mobile header for coach/admin */}
        <div className="lg:hidden sticky top-0 z-30 bg-slate-950/95 backdrop-blur-xl border-b border-slate-800 px-4 py-3">
          <div className="flex items-center justify-between">
            <button
              onClick={() => setIsSidebarOpen(true)}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            >
              <Menu className="w-6 h-6" />
            </button>
            <h1 className="font-bold text-white">F.Y.T</h1>
            <div className="w-10" />
          </div>
        </div>

        <div className="p-4 lg:p-8">
          {dataLoading ? (
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full" />
            </div>
          ) : (
            <>
              {currentView === 'home' && (
                <Home
                  data={trainingData}
                  filters={filters}
                  setFilters={setFilters}
                  onStartSession={handleStartSession}
                  user={currentUser}
                  history={history}
                  activeWeekOrganizers={activeWeekOrganizers}
                  pastWeekOrganizers={pastWeekOrganizers}
                />
              )}

              {currentView === 'active' && activeSessionData && (
                <ActiveSession
                  sessionData={activeSessionData}
                  history={history}
                  onSave={handleSaveSession}
                  onCancel={handleCancelSession}
                  initialLog={editingSession}
                  userId={currentUser.id}
                  onSaveComment={handleSaveAthleteComment}
                />
              )}

              {currentView === 'history' && (
                <History
                  history={history}
                  onDelete={handleDeleteSession}
                  onEdit={handleEditSession}
                  userId={currentUser.id}
                />
              )}

              {currentView === 'team' && (isCoach || isAdmin) && (
                <TeamView
                  coachId={currentUser.id}
                  fetchTeam={handleFetchTeam}
                  fetchAthleteHistory={handleFetchAthleteHistory}
                  fetchTeamComments={handleFetchTeamComments}
                  markCommentsAsRead={handleMarkCommentsAsRead}
                  fetchWeekOrganizerLogs={handleFetchWeekOrganizerLogs}
                  saveWeekOrganizerLog={handleSaveWeekOrganizerLog}
                  deleteWeekOrganizerLog={handleDeleteWeekOrganizerLog}
                  fetchAthleteGroups={handleFetchAthleteGroups}
                  createAthleteGroup={handleCreateAthleteGroup}
                  updateAthleteGroup={handleUpdateAthleteGroup}
                  deleteAthleteGroup={handleDeleteAthleteGroup}
                  updateGroupMembers={handleUpdateGroupMembers}
                  loadGroupMembers={handleLoadGroupMembers}
                />
              )}

              {currentView === 'admin' && isAdmin && (
                <AdminUsersView
                  fetchAllUsers={handleFetchAllUsers}
                  updateCoach={handleUpdateCoach}
                />
              )}

              {currentView === 'settings' && (
                <SettingsView
                  user={currentUser}
                  onUpdateProfile={handleUpdateProfile}
                  onLogout={handleLogout}
                  activeMode={activeMode}
                  canSwitchToCoach={canSwitchToCoach}
                  canSwitchToAthlete={canSwitchToAthlete}
                  onSwitchMode={handleSwitchMode}
                />
              )}

              {currentView === 'import' && (
                <StravaImport user={currentUser} />
              )}
            </>
          )}
        </div>
      </main>
    </div>
  );
};

export default App;
